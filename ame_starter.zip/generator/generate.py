import os, json, datetime, yaml
from jinja2 import Environment, FileSystemLoader, select_autoescape

ROOT = os.path.dirname(os.path.dirname(__file__))
DIST = os.path.join(ROOT, "dist")
TPL = os.path.join(ROOT, "generator", "templates")

os.makedirs(DIST, exist_ok=True)

with open(os.path.join(ROOT, "site", "config.yaml"), "r", encoding="utf-8") as f:
    cfg = yaml.safe_load(f)

with open(os.path.join(ROOT, "generator", "pages.json"), "r", encoding="utf-8") as f:
    PAGES = json.load(f)

env = Environment(
    loader=FileSystemLoader(TPL),
    autoescape=select_autoescape()
)

def render_to(tpl_name, out_name, **ctx):
    tpl = env.get_template(tpl_name)
    html = tpl.render(**ctx)
    with open(os.path.join(DIST, out_name), "w", encoding="utf-8") as f:
        f.write(html)

base_ctx = {
    "site_name": cfg.get("site_name","TinyToolsHub"),
    "adsense_client_id": cfg.get("adsense_client_id",""),
    "base_path": "",
    "year": datetime.datetime.now().year
}

# Copy static assets already placed in dist/assets and dist/calculators

# Render individual pages
pages_meta = []
for p in PAGES:
    ctx = dict(base_ctx)
    ctx.update({
        "title": p["title"],
        "description": p["description"],
        "h1": p.get("h1", p["title"]),
        "lede": p.get("lede",""),
        "steps": p.get("steps", []),
        "calculator_component": p.get("calculator_component"),
        "calculator_js": p.get("calculator_js"),
        "calc_title": p.get("calc_title", "Calculator"),
        "tips": p.get("tips", []),
        "recommendations": p.get("recommendations", []),
    })
    render_to("page.html", f"{p['slug']}.html", **ctx)
    pages_meta.append({
        "slug": p["slug"],
        "title": p["title"],
        "description": p["description"],
        "category": p.get("category","")
    })

# Index & all pages
render_to("index.html", "index.html", pages=pages_meta, **base_ctx)
render_to("all.html", "all.html", pages=pages_meta, **base_ctx)
render_to("about.html", "about.html", **base_ctx)

print(f"Built {len(PAGES)} pages → dist/")
